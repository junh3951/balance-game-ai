// app/[roomId]/result/_components/result_title.jsx
'use client'

export default function ResultTitle() {
	return <h1 className="text-2xl font-bold mt-4">결과</h1>
}
