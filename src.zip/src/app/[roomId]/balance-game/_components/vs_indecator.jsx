// app/[roomId]/balance-game/_components/vs_indecator.jsx
'use client'

export default function VSIndicator() {
	return <div className="mx-2 text-2xl font-bold">VS</div>
}
