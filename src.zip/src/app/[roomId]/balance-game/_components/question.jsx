// app/[roomId]/balance-game/_components/question.jsx
'use client'

export default function Question({ text }) {
	return <h1 className="text-2xl font-bold mt-4">{text}</h1>
}
