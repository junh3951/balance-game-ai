// import { ReactNode } from "react";
// import { atom } from "recoil";

// interface DrawerProps {
//   children: string | ReactNode;
//   open: boolean;
//   title: string | ReactNode;
//   subtitle?: string | ReactNode;
//   onClose?: () => void;
// }

// export const DrawerState = atom<DrawerProps>({
//   key: "drawer",
//   default: {
//       open: false,
//       title: "" as string | ReactNode,
//       subtitle: "" as string | ReactNode,
//       children: "" as string | ReactNode
//   }
// });
