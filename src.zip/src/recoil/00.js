// import { USER } from '@/domain/model/user_model'
// import { atom } from 'recoil'

// export const UserDataState = atom({
// 	key: 'user_data',
// 	default: {
// 		id: '',
// 		name: '',
// 		phone: '',
// 		door_num: 0,
// 		door_size: {},
// 		door_spec: {},
// 		picture_url: {},
// 		last_step: 0,
// 		is_confirmed: false,
// 		is_done: false,
// 		created_at: new Date().toISOString(),
// 	} as USER,
// })
