// import { atom } from 'recoil'

// export const ContainerInfoState = atom({
// 	key: 'container_info',
// 	default: {
// 		backgroundColor: 'white',
// 		type: 'auth' as 'auth' | 'main',
// 	},
// })
